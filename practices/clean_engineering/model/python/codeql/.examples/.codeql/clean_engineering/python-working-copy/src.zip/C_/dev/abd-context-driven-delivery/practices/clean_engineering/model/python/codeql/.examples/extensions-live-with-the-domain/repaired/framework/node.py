class Node:
    pass
