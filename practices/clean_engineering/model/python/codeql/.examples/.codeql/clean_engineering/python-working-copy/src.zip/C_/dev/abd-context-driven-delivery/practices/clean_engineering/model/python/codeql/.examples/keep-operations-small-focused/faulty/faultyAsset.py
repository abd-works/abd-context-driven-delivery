def string_block():
    text = """
    a multi-line string is one statement
    not a line per fragment
    """
    run = dict(
        language="python",
        source_root="repo",
        command="echo skip",
        extra="x",
        more="y",
    )
    return text, run


def huge():
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    f = 6
    g = 7
    h = 8
    i = 9
    j = 10
    k = 11
    l = 12
    m = 13
    n = 14
    o = 15
    p = 16
    q = 17
    r = 18
    s = 19
    t = 20
    u = 21
    return a + b + c
