class OrphanModule:
    pass
