export class Orders {
  beneficiaryBank = "";
}
