class PlanEntity:
    id: str
