export class AccountCredentials {
  email = ""
}
