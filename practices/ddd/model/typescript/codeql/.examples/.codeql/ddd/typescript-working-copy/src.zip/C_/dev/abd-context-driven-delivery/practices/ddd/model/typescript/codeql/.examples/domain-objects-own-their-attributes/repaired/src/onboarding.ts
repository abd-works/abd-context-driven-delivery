export class Onboarding {
  status = ""
}
