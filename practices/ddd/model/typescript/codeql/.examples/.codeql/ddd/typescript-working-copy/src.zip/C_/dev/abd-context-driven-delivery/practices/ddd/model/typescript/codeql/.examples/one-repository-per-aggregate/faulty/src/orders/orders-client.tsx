export class OrdersClientRepository {
  load() {}
}
