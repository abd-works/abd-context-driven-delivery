export class OrdersRepositoryNode {
  load() {}
}
