export class CustomerRepository {
  customerId = ""
}
