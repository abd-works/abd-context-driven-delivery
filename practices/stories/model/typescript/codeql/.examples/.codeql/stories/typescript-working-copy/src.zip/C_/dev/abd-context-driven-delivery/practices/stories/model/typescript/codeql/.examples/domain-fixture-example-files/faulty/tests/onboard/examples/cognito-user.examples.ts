export const storedUser = {}
