export const storedAccountCredentials = {}
