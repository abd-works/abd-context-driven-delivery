export const validCustomer = {}
