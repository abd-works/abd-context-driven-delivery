export const storedCustomer = {}
