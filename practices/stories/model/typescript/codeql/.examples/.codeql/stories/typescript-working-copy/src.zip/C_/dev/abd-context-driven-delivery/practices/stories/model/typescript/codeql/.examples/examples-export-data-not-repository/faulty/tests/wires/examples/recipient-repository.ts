export const recipientRepository = { new: () => ({}) };
