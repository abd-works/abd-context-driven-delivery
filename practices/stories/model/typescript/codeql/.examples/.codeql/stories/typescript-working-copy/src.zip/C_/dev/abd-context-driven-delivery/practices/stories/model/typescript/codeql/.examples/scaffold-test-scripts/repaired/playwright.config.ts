export default { testDir: "tests" };
